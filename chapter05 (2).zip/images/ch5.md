

## Mapping Static Web Site Files into a Web Server Continer



![WelcomeToNginx.png](C:\Users\jp.lee\Downloads\chapter05\images\WelcomeToNginx.png)





![SolitaireWebSite.png](C:\Users\jp.lee\Downloads\chapter05\images\SolitaireWebSite.png)




![VolumeMount.png](C:\Users\jp.lee\Downloads\chapter05\images\VolumeMount.png)



![CopyIntoTheContainerFileSystem.png](C:\Users\jp.lee\Downloads\chapter05\images\CopyIntoTheContainerFileSystem.png)




![BakeIntoAnImage.png](C:\Users\jp.lee\Downloads\chapter05\images\BakeIntoAnImage.png)




![WebSiteStaticFiles.png](C:\Users\jp.lee\Downloads\chapter05\images\WebSiteStaticFiles.png)



## Volume Mount Web Site File


![nginxRun.png](C:\Users\jp.lee\Downloads\chapter05\images\nginxRun.png)

![dockerHubNginx.png](C:\Users\jp.lee\Downloads\chapter05\images\dockerHubNginx.png)

![WelcomeToNginx.png](C:\Users\jp.lee\Downloads\chapter05\images\WelcomeToNginx.png)

![WebSiteFiles.png](C:\Users\jp.lee\Downloads\chapter05\images\WebSiteFiles.png)



![nginxVolume.png](C:\Users\jp.lee\Downloads\chapter05\images\nginxVolume.png)


![SolitairePath2.png](C:\Users\jp.lee\Downloads\chapter05\images\SolitairePath2.png)


![VolumeMountPath.png](C:\Users\jp.lee\Downloads\chapter05\images\VolumeMountPath.png)


![ShareDrive1.png](C:\Users\jp.lee\Downloads\chapter05\images\ShareDrive1.png)


![ShareDrive2.png](C:\Users\jp.lee\Downloads\chapter05\images\ShareDrive2.png)


![SolitaireWebSite.png](C:\Users\jp.lee\Downloads\chapter05\images\SolitaireWebSite.png)




## Modifying FIles in a Running Container


![dockerHelpExec.png](C:\Users\jp.lee\Downloads\chapter05\images\dockerHelpExec.png)




![dockerExec.png](C:\Users\jp.lee\Downloads\chapter05\images\dockerExec.png)





![nginxHtml.png](C:\Users\jp.lee\Downloads\chapter05\images\nginxHtml.png)





![IndexChange.png](C:\Users\jp.lee\Downloads\chapter05\images\IndexChange.png)



![ModifyNginxIndex.png](C:\Users\jp.lee\Downloads\chapter05\images\ModifyNginxIndex.png)


## Copying Files into a Running Container



![dockerHelpCP.png](C:\Users\jp.lee\Downloads\chapter05\images\dockerHelpCP.png)


![dockerContainerLS.png](C:\Users\jp.lee\Downloads\chapter05\images\dockerContainerLS.png)

![dockerCpCommand.png](C:\Users\jp.lee\Downloads\chapter05\images\dockerCpCommand2.png)



![CopyIntoTheContainerFileSystem2.png](C:\Users\jp.lee\Downloads\chapter05\images\CopyIntoTheContainerFileSystem2.png)


## Baking Files into an Image from a Container



![dockerPS_exec.png](C:\Users\jp.lee\Downloads\chapter05\images\dockerPS_exec.png)





![dockerHelpCommit.png](C:\Users\jp.lee\Downloads\chapter05\images\dockerHelpCommit.png)



![dockerCommit.png](C:\Users\jp.lee\Downloads\chapter05\images\dockerCommit.png)








































